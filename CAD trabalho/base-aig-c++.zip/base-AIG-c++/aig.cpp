//copyright Prof. Andre Reis - UFRGS


#include "aig.h"


AndNode::AndNode(int, int, int)
{}

bool Aig::insert(AndNode *)
{}

bool Aig::insert(InputNode *)
{}

bool Aig::insert(OutputNode *)
{}
   
